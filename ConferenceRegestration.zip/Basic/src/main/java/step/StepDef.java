package step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import util.WebDriverUtil;

public class StepDef {
	private WebDriver webdriver;
	
	@Given("^I opened google page$")
	public void i_opened_google_page() throws Throwable {
		
		webdriver=WebDriverUtil.getDriver();
		webdriver.manage().window().maximize();
		webdriver.get("https://www.google.com/");
	}

	@When("^I type query in searchBox$")
	public void i_type_query_in_searchBox() throws Throwable {
		WebElement el=webdriver.findElement(By.name("q"));
		el.sendKeys("I am just awesome");
		
	}

	@When("^click google search button$")
	public void click_google_search_button() throws Throwable {
		WebElement el=webdriver.findElement(By.name("btnK"));
		el.submit();
	}

	@Then("^verfiy google title$")
	public void verfiy_google_title() throws Throwable {
		WebDriverUtil.closeDriver();
	}

}
