package util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverUtil {

	private static WebDriver driver;
	static {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Driver\\chromedriver.exe");
		
	}
	public static WebDriver getDriver() {
		driver=new ChromeDriver();
		return driver;
	}
	public static void closeDriver() {
		driver.quit();
	}
}
