package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.capg.bean.AddProduct;
import com.capg.repo.IMerchantRepo;

@Service
public class MerchantService implements IMerchantService {

	@Autowired
	IMerchantRepo repo;
	
	@Override
	public void addProduct(AddProduct product) {
		
		repo.save(product);
		
	}

}
