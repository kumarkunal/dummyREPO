package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.capg")
public class Module12BackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(Module12BackEndApplication.class, args);
	}
}
