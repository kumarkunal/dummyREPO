package com.capg.service;

import com.capg.bean.AddProduct;

public interface IMerchantService {
	
	public void addProduct(AddProduct product);

}
