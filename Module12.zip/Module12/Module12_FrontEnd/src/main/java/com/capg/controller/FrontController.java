package com.capg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capg.beans.AddProduct;

@Controller
public class FrontController {
	
	
	@RequestMapping("/addpro")
	public String addProduct(AddProduct product) {
		
	RestTemplate rest=new RestTemplate();
	System.out.println(product.getProductId());
	String url = "http://localhost:9092/addpro";
	String abc=rest.postForObject(url,product,String.class);
	return "Success";
	}

	
	
}
